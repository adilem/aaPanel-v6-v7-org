def get_module(filename: str):
    import PluginLoader
    return PluginLoader.get_module(filename)
