const t="/static/vite/images/update-back.png";export{t as _};
