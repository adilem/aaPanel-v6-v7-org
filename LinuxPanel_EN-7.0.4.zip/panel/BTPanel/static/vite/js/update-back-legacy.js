System.register([],(function(t,e){"use strict";return{execute:function(){t("_","/static/vite/images/update-back.png")}}}));
