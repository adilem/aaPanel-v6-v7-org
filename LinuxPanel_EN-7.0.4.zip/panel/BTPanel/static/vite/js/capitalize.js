import{bU as o,bF as r}from"./index.js?v=1717670349083";function e(e){return o(r(e).toLowerCase())}export{e as c};
