System.register([],(function(t,e){"use strict";return{execute:function(){t("b",(function(t,e,r,n){for(var u=t.length,i=r+-1;++i<u;)if(e(t[i],i,t))return i;return-1}))}}}));
