import{bT as o,bE as r}from"./index.js?v=1717070502408";function e(e){return o(r(e).toLowerCase())}export{e as c};
