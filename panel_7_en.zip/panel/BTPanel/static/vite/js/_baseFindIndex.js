function r(r,n,t,e){for(var f=r.length,o=t+-1;++o<f;)if(n(r[o],o,r))return o;return-1}export{r as b};
